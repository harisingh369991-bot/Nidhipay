# NidhiPay Demo

यह एक mobile-friendly frontend demo है।

## चलाने का तरीका
`index.html` को browser में खोलें।

## इसमें
- Landing page
- Register/Login UI
- Demo balance
- Referral rewards
- Deposit/withdrawal request buttons
- Transaction history
- Responsive mobile design

यह version real money collect या payout नहीं करता। Real deployment के लिए secure backend, database, authentication, payment provider, KYC/AML और लागू कानूनों के अनुसार compliance की आवश्यकता होगी।
